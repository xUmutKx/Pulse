Release notes
=============

Pillow is released quarterly on January 2nd, April 1st, July 1st and October 15th.
Patch releases are created if the latest release contains severe bugs, or if security
fixes are put together before a scheduled release. See :ref:`versioning` for more
information.

Please use the latest version of Pillow. Functionality and security fixes should not be
expected to be backported to earlier versions.

.. note:: Contributors please include release notes as needed or appropriate with your bug fixes, feature additions and tests.

.. toctree::
  :maxdepth: 2

  versioning
  12.3.0
  12.2.0
  12.1.1
  12.1.0
  12.0.0
  11.3.0
  11.2.1
  11.1.0
  11.0.0
  10.4.0
  10.3.0
  10.2.0
  10.1.0
  10.0.1
  10.0.0
  9.5.0
  9.4.0
  9.3.0
  9.2.0
  9.1.1
  9.1.0
  9.0.1
  9.0.0
  8.4.0
  8.3.2
  8.3.1
  8.3.0
  8.2.0
  8.1.2
  8.1.1
  8.1.0
  8.0.1
  8.0.0
  7.2.0
  7.1.2
  7.1.1
  7.1.0
  7.0.0
  6.2.2
  6.2.1
  6.2.0
  6.1.0
  6.0.0
  5.4.1
  5.4.0
  5.3.0
  5.2.0
  5.1.0
  5.0.0
  4.3.0
  4.2.1
  4.2.0
  4.1.1
  4.1.0
  4.0.0
  3.4.0
  3.3.2
  3.3.0
  3.2.0
  3.1.2
  3.1.1
  3.1.0
  3.0.0
  2.8.0
  2.7.0
  2.6.0
  2.5.2
  2.3.2
  2.3.1
